package com.example.mello.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RelistActivity extends AppCompatActivity{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relist);
    }
}
